# OpenSSL Binary for Decrypting Keybox

This folder contains the **OpenSSL binary** needed to decrypt your **encrypted Keybox**. I've included it in this module to save you some time during setup.

## How to Use

1. **Pre-packaged OpenSSL Binary**:  
   The binary is already packaged here, so you don’t need to worry about installing it manually. This will automatically handle the decryption for you when the module is installed.

2. **Install via Termux (Alternative)**:  
   If you'd rather install it yourself, you can use this command in Termux:

   ```
   pkg install openssl-tool
   ```

   This will install the OpenSSL tools needed to decrypt the Keybox & the file extraction will be skipped & deleted automatically.

## Important Notes

- **One-Time Setup**:  
   The OpenSSL binary is needed just once to decrypt the Keybox. After that, future module installations will **skip** the extraction step automatically.
   
## Any doubt?
ping me on telegram **@TempMeow**

Group Chat : https://t.me/+bKUOLxF_K_IyNDY1